import{a as t}from"../chunks/entry.--1BeJL5.js";export{t as start};
